// ------------------ For future reference ------------------
// Hvis du skal endre på denne siden og få det til å passe
// klassa di trenger man bare endre quotene basert på
// navnene i denne lista her. Hvis dere er flere eller
// færre tar koden hensyn til det.

function getQuote(hvem) {
  switch (hvem) {
    case "Josue": return "læl ikke norgesmester lengre";
      break;
    case "Sander": return "Wannabe emo kid";
      break;
    case "Anders KF": return "D mÅ vÆrE 37";
      break;
    case "Markus K": return "Pass deg ellers jammer jeg nettet ditt";
      break;
    case "Fredrik": return "Cracka fortnite gud, huuuuh";
      break;
    case "Kjetil": return "Ting skal ikke inn i tissen,<br> tissen skal inn i ting - Kjetil 2019";
      break;
    case "Stian": return "Nå roer vi oss ned her";
      break;
    case "Sindre": return "If her age is on the clock, she is ready for the cock";
      break;
    case "Alex": return "Kjørte av i 120, gleder meg til 240";
      break;
    case "Adrian": return "Adrian skrur på PCen: *Jet engine starting up*";
      break;
    case "Vidar": return "Eiii. Veitta faen je";
      break;
    case "Scott": return "Ginger og kan OD'e på sukker. Hmu";
      break;
    case "Markus RD": return "Aner ikke je, finn på dere";
      break;
    case "Vetle": return "bennebjønn";
      break;
    case "Vegard B": return "Jeg har flere kuer enn deg, faktisk";
      break;
    case "Eline": return "U real gamer grill?";
      break;
    case "Magnus": return "Jeg er jævelig tett,<br> i nesa";
      break;
    case "Eduard": return "скатерть";
      break;
    case "Vegard E": return ":-(";
      break;
    case "Anders E": return "Big brain big dick";
      break;
    default: return "Well this is awkward";
  }
}
