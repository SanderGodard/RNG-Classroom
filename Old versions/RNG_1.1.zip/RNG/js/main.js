// ------------------ For future reference ------------------
// Hvis du skal endre på denne siden og få det til å passe
// klassa di trenger man bare endre navnene i denne lista
// her. Hvis dere er flere eller færre tar koden hensyn til
// det.

idioter = [
"Kjetil",
"Eline",
"Vegard B",
"Markus RD",
"Vidar",
"Anders E",
"Vegard E",
"Anders KF",
"Fredrik",
"Stian",
"Scott",
"Magnus",
"Josue",
"Markus K",
"Sindre",
"Sander",
"Alex",
"Eduard",
"Adrian",
"Vetle",
];
//eidioter = idioter;
borteidag = idioter;

for (var i = 0; i < idioter.length; i++) {
  navn = idioter[i];
  fraversListe = document.getElementsByClassName('fraver')[0].children[0];
  poengListe = document.getElementsByClassName('poeng')[0].children[0];
  fraverLi = document.createElement('li');
  poengLi = document.createElement('li');
  wrapper = document.createElement('a');
  wrapper.setAttribute("href", "javascript:void(0)");
  wrapper.setAttribute("id", navn);
  //wrapper.setAttribute("type", "button");
  //wrapper.setAttribute("name", navn);
  wrapper.setAttribute("onclick", 'bortenavn("' + navn + '")');
  wrapper.innerHTML = navn;

  divScore = document.createElement('div');
  poengChange = document.createElement('div');
  score = document.createElement('span');
  minus = document.createElement('span');
  plus = document.createElement('span');
  score.setAttribute("id", "point" + idioter[i]);
  minus.setAttribute("onclick", "removePoint('" + idioter[i] + "')");
  plus.setAttribute("onclick", "addPoint('" + idioter[i] + "')");
  score.innerHTML = "0";
  minus.innerHTML = "-";
  plus.innerHTML = "+";

  fraversListe.appendChild(fraverLi);
  fraverLi.appendChild(wrapper);

  poengListe.appendChild(poengLi);
  poengLi.appendChild(divScore);
  divScore.appendChild(score);
  divScore.appendChild(poengChange);
  poengChange.appendChild(minus);
  poengChange.appendChild(plus);
}

var y = 0;
var antall = idioter.length/4*3;
var vis = 0;



function btn(){
  document.getElementsByClassName("quote")[0].innerHTML = "";
  w = 0;
}

function resetRecent() {
  idioter = borteidag.slice(0);
  y = 0;
  for(r=1; r<antall + 1; r++) {
    document.getElementById("List" + r).children[0].children[0].innerHTML = "";
  }
}

function buttonsActive(state) {
  buttons = document.getElementsByClassName('button');
  for (var i = 0; i < buttons.length; i++) {
    if (state) {
      buttons[i].style.cursor = "pointer";
      buttons[i].style.pointerEvents = "auto";
    } else {
      buttons[i].style.cursor = "not-allowed";
      buttons[i].style.pointerEvents = "none";
    }
  }
}

function runRNG() {
  // sets class "button" to be disabled...
  buttonsActive(false);
  if (y >= antall) {
    resetRecent();
  }
  y++;
  for(i=0; i<100; ++i) {
    setTimeout(function() {
      var person = idioter[Math.floor((Math.random() * idioter.length))];
      document.getElementsByClassName("name")[0].innerHTML = person;
      document.getElementsByClassName("quote")[0].innerHTML = "";

    }, Math.sqrt(i) * 500);
  }
  randomIdiot();
}



function randomIdiot() {
  setTimeout(function() {
    buttonsActive(true);
    person = document.getElementsByClassName("name")[0].innerHTML
    document.getElementById("List" + y).children[0].children[0].innerHTML = person;
    document.getElementsByClassName("quote")[0].innerHTML = getQuote(person);

    var audio = new Audio('elements/bruh.mp3');
    audio.play();
  }, 10 * 600);
}



function bortenavn(navn){
  if (borteidag.indexOf(navn) >= 0) {
    //console.log(navn);

    document.getElementById(navn).setAttribute("class", "borte");
    document.getElementById("point" + navn).parentNode.setAttribute("class", "borte");

    if (borteidag.length == antall) {
        minusAntall();
    }


    var index = idioter.indexOf(navn);
    if (idioter.indexOf(navn) != -1){
      idioter.splice(index, 1);
      //borteidag.splice(index, 1);
      borteidag = idioter;
    } else {
      die("Error skjedd mens endring av fravær skulle endres i arrayet.");
    }

    //antall = borteidag.length;
    //trekkninger();
  } else {
    //console.log(navn + " mordi");
    document.getElementById(navn).setAttribute("class", "");
    document.getElementById("point" + navn).parentNode.setAttribute("class", "");

    //borteidag.push(navn);
    idioter.push(navn);
    borteidag = idioter;


    //antall = borteidag.length;
    //trekkninger();
  }
}



function trekkninger() {
  document.getElementById("trekkninger").innerHTML = antall;

  antallListe = document.getElementsByClassName("recent")[0].children[0];

  /*
for (i=0; i<wrapper.children.length; i++) {
    del = wrapper.children[i];
    del.parentNode.removeChild(del);
    console.log(del);
  }*/


  for (var i = 0; i<antall; i++) {
    li = document.createElement('li');
    span = document.createElement('span');
    span2 = document.createElement('span');
    li.setAttribute("class", "liste");
    li.setAttribute("id", ("List" + (i+1)));

    antallListe.appendChild(li);
    li.appendChild(span);
    span.appendChild(span2);
  }


  //'<li id="List1" class="liste"> </li>"'
}



function plussAntall() {
  if (antall != borteidag.length) {
    antall++;

    antallListe = document.getElementsByClassName("recent")[0].children[0];
    li = document.createElement('li');
    span = document.createElement('span');
    span2 = document.createElement('span');
    li.setAttribute("class", "liste");
    li.setAttribute("id", ("List" + antall));
    li.setAttribute("class", "liste");
    antall = parseInt(antall);
    antallListe.appendChild(li)
    li.appendChild(span);
    span.appendChild(span2);
    document.getElementById("trekkninger").innerHTML = antall;
  }
}



function minusAntall() {
  if (document.getElementById("List" + (antall)).children[0].children[0].innerHTML == "") {
    if (antall != 1){

      remove = document.getElementById("List" + (antall));
      remove.parentNode.removeChild(remove);

      antall--;
      antall = parseInt(antall);
      document.getElementById("trekkninger").innerHTML = antall;
    }
  }
}


function fargeMode(farge) {
  switch (farge) {
    case "rosa": document.getElementById('style').href = 'css/rosa.css';
      break;
    case "hvit": document.getElementById('style').href = 'css/hvit.css';
      break;
    case "svart": document.getElementById('style').href = 'css/main.css';
      break;
    default:document.getElementById('style').href = 'css/main.css';

  }

}


function addPoint(navn) {
  counter = document.getElementById("point" + navn);
  num = counter.innerHTML;
  num = parseInt(num);
  num++;
  counter.innerHTML = num;
}


function removePoint(navn) {
  counter = document.getElementById("point" + navn);
  num = counter.innerHTML;
  num = parseInt(num);
  num--;
  counter.innerHTML = num;
}
